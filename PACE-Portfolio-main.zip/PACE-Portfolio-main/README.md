# PACE-Portfolio 
PACE (Personal Academic Companion & Evaluator) is a mobile application designed to support high school and college students in managing their academic responsibilities. The app centralizes task 
tracking, personalized quiz generation, summarization tools, and ambient focus features. It aims to reduce stress caused by fragmented digital tools, encourage pacing, and support diverse learning styles
